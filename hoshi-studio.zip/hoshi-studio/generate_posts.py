"""
Run this ONCE to generate all 210 posts and save posts.json.
Usage: ANTHROPIC_API_KEY=your_key python3 generate_posts.py
"""
import json, os, urllib.request

API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
if not API_KEY:
    print("Error: Set ANTHROPIC_API_KEY environment variable")
    exit(1)

all_posts = []

for day in range(1, 31):
    prompt = f"""You are the content creator for "Hoshi Studio", a Telegram channel for ambitious Persian-speaking young women. Bittersweet, dreamy tone.

STYLE: Short (1-4 lines). Rotate Persian/English/Japanese. Emojis: ✨🌙🎀🌸⭐🔮🪐🤍🔥💫
Quotes: quote → "𓄳 Author" → "☆ Hoshi Studio". NO hashtags.

Day {day}/30. Generate 7 posts in this order:
1. Persian ambitious affirmation
2. Literary quote with Persian translation + attribution
3. Japanese proverb + Persian translation
4. Raw honest Persian confession
5. Punchy productivity/dream post (any language)
6. Cozy life moment
7. English aesthetic one-liner

Return ONLY a JSON array of 7 strings."""

    body = json.dumps({
        "model": "claude-sonnet-4-6",
        "max_tokens": 1000,
        "messages": [{"role": "user", "content": prompt}]
    }).encode()

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={"Content-Type": "application/json", "x-api-key": API_KEY, "anthropic-version": "2023-06-01"},
        method="POST"
    )

    with urllib.request.urlopen(req, timeout=30) as r:
        data = json.loads(r.read())

    text = data["content"][0]["text"]
    clean = text.replace("```json", "").replace("```", "").strip()
    posts = json.loads(clean)
    all_posts.extend(posts)
    print(f"Day {day}/30 ✅")

with open("posts.json", "w", encoding="utf-8") as f:
    json.dump(all_posts, f, ensure_ascii=False, indent=2)

print(f"Done! {len(all_posts)} posts saved to posts.json")
