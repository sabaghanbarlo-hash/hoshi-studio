# ✨ Hoshi Studio — Telegram Auto Poster

Automated 30-day content system for [@hooshistudio](https://t.me/hooshistudio)

## How it works
- GitHub Actions runs every 3 hours automatically
- Posts one of 210 pre-generated posts to the Telegram channel
- Posts rotate in order: Day 1 → Day 30

## Posting schedule (Tehran time)
| Slot | Time |
|------|------|
| 1 | 06:00 |
| 2 | 09:00 |
| 3 | 12:00 |
| 4 | 15:00 |
| 5 | 18:00 |
| 6 | 21:00 |
| 7 | 00:00 |

## Setup
1. Add these GitHub Secrets (Settings → Secrets → Actions):
   - `TELEGRAM_BOT_TOKEN` — your bot token from @BotFather
   - `TELEGRAM_CHAT_ID` — `-1003947742617`

2. Enable GitHub Actions in the Actions tab

## Manual post
Go to Actions → Hoshi Studio Auto Post → Run workflow → enter a post index (0-209)
